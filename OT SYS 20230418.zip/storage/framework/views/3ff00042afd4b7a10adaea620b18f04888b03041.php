

    <div class="max-w mx-auto ">

        <div class="p-6 bg-white">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Dashboard')); ?>

            </h2>
        </div>

        <div class="grid grid-cols-4 gap-4 max-w-7xl mx-auto px-3 py-5">
            
            <div class="bg-sky-700 overflow-hidden shadow-xl  px-6 py-5 text-md text-white font-medium h-48">
                

                <?php if(Auth::user()->user_level == 12): ?>

                    <?php $c=0?> 
                    <?php $__currentLoopData = $level12; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $c++ ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> OT Sheets to be Submited</a>
                <?php endif; ?>

                <?php if((Auth::user()->user_level == 11) || (Auth::user()->user_level == 10)): ?>

                    <?php $c=0?> 
                    <?php $__currentLoopData = $level10_11; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $c++ ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> OT Sheets to be Submited</a>
                <?php endif; ?>               
            </div>

            
            <div class="bg-sky-700 overflow-hidden shadow-xl  px-6 py-5 text-white font-medium h-48">
                
                <a href=""> <div class="text-6xl font-bold">0</div>Incomplete OT Sheets </a>
                              
            </div>

            <div class="bg-sky-700 overflow-hidden shadow-xl  px-6 py-5 text-lg text-white font-medium h-48">
                
                <a href=""> <div class="text-6xl font-bold">0</div>Porcessing OT Sheets </a>
                             
            </div>

            <div class="bg-sky-700 overflow-hidden shadow-xl  px-6 py-5 text-lg text-white font-medium h-48">
                

                              
            </div>
          </div>




        
    </div>
<?php /**PATH D:\Laravel Project\Laravel9\OT\OT SYS 20221008\resources\views/livewire/otdashboard.blade.php ENDPATH**/ ?>