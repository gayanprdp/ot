

<div>
  
 


  <div class="grid grid-cols-2 p-4 bg-white" >
    <div>
      <h2 class="font-semibold text-xl text-sky-800 leading-tight">
        <?php echo e(__('OT Sheet - ')); ?>

        
        <?php 
        $nitifi=DB::table("ot_list")->join("institute","institute.id","=","ot_list.institute_id")->where('ot_list.id', '=', $param )->get()
        ?> 
         <?php $__currentLoopData = $nitifi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php echo e($item->year); ?> - <?php echo e($item->month); ?> 
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
      </h2>
        <?php 
        $nitifi=DB::table("ot_list")->join("institute","institute.id","=","ot_list.institute_id")->where('ot_list.id', '=', $param )->get()
        ?> 
         <?php $__currentLoopData = $nitifi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <p class="text-sky-800"><?php echo e($item->institute); ?></p>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div>
      <div class="flex justify-end m-2 p-2">

        <input type="search" wire:model="search" placeholder="Search..." class="block w-64 appearance-none bg-white border border-sky-700 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5">

      </div>
      <div class="flex justify-end m-2 p-2">

    

        
        <div class="hidden"><?php echo e($otrec=DB::table("ot_list_status")->select('id','List_id','ot_range')->where('List_id', '=', $this->param)->where('ot_range', '=', $this->param2 )->get()); ?></div>   
        <div class="hidden"><?php echo e($otrec1=DB::table("ot_records")->where('List_id', '=', $this->param )->where('ot_range', '=', $this->param2 )->get()); ?></div> 
        <div class="hidden"><?php echo e($otrec2=DB::table("ot_records")->where('List_id', '=', $this->param )->where('ot_range', '=', $this->param2 )->where('mark', '=', '1' )->get()); ?></div> 
          <?php $__currentLoopData = $otrec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <?php if(Auth::user()->user_level!=1): ?>
                <?php if($otrec1->count()==0): ?>                
                  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>                
                <?php else: ?>
                  <?php if($param1==1): ?>                   
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                  <?php else: ?>

                        <?php if($otrec2->count()!=0): ?> 
                          <?php if(Auth::user()->user_level!=8): ?> 
                          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-sky-600 mr-2','wire:click' => 'ShowResubmitModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-sky-600 mr-2','wire:click' => 'ShowResubmitModal']); ?>Resubmit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                          <?php endif; ?>
                          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php else: ?>

                                <?php if((Auth::user()->user_level==6)&& ($this->param2=='r1')||((Auth::user()->user_level==3)&& ($this->param2=='r2')) ||((Auth::user()->user_level==2)&& ($this->param2=='r3'))): ?> 
                                          
                                          <?php if(Auth::user()->user_level!=8 && ($otrec2->count()!=0)): ?>  
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-sky-600 mr-2','wire:click' => 'ShowResubmitModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-sky-600 mr-2','wire:click' => 'ShowResubmitModal']); ?>Resubmit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                          <?php else: ?> 
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-gray-700 hover:bg-gray-700 mr-2']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-gray-700 hover:bg-gray-700 mr-2']); ?>Resubmit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                                          <?php endif; ?> 

                                  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'ShowForwardModal','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'ShowForwardModal','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Approve <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php else: ?>
                                          <?php if(Auth::user()->user_level!=8): ?>
                                          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-gray-700 hover:bg-gray-700 mr-2']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-gray-700 hover:bg-gray-700 mr-2']); ?>Resubmit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                          <?php endif; ?>
                                  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'ShowForwardModal','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'ShowForwardModal','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?>
                        <?php endif; ?>  

                  <?php endif; ?>               
                <?php endif; ?>  
            <?php endif; ?>              
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         

       



        <?php if($param1==1): ?>
          <?php if((Auth::user()->user_level == 8 )|| (Auth::user()->user_level == 11 )): ?>
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300']); ?>Add New Record <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> &nbsp;
          <?php endif; ?>
        <?php else: ?>
          <?php if((Auth::user()->user_level == 8 )|| (Auth::user()->user_level == 11 )): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'showOtRecordModal','class' => 'bg-sky-800 hover:bg-sky-600 ']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'showOtRecordModal','class' => 'bg-sky-800 hover:bg-sky-600 ']); ?>Add New Record <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> &nbsp;
          <?php endif; ?>
        
        <?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'hidden bg-sky-800 hover:bg-sky-600 mx-1','wire:click' => 'printotrecords('.e($param).')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hidden bg-sky-800 hover:bg-sky-600 mx-1','wire:click' => 'printotrecords('.e($param).')']); ?>Print <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"  class="bg-sky-800 hover:bg-sky-600 text-white rounded-md py-1 px-3 text-base leading-normal ">Back</a> &nbsp;
        
      </div>
    </div>
  </div>

  
  <div class="max-w mx-auto px-3 py-1 bg-gray-100">
    <table  class="w-full divide-y divide-sky-700">
      <div class="bg-sky-800 text-sky-800 dark:bg-gray-600 dark:text-gray-200 rounded-tl-lg rounded-tr-lg h-2">.  </div>
      <thead class="bg-sky-800 dark:bg-gray-600 dark:text-gray-200">
        <tr>
          <td scope="col" class="relative px-6 py-3 col-md-2 font-semibold text-white">ID</td>        
          <td scope="col" class="relative px-6 py-3 col-md-1 font-semibold text-white">EMPLOYEE</br>නිලධාරියාගේ නම</td>
          <td scope="col" class="relative px-6 py-3 col-md-3 font-semibold text-white">DESIGNATION</br>තනතුර</td>
          <td scope="col" class="relative px-6 py-3 col-md-2 font-semibold text-white w-1/10">NATURE OF DUTIES </br>රාජකාරී ස්වභාවය</td>

          <?php if( (Auth::user()->user_level == 8) || (Auth::user()->user_level == 7)|| (Auth::user()->user_level == 11)): ?>
            <td scope="col" class="relative px-6 py-3 col-md-2 font-semibold text-white">Suggested Hours</br>යෝජිත පැය ගනන</td>
          <?php endif; ?>

          <?php if((Auth::user()->user_level == 6) ): ?>
            <td scope="col" class="relative px-6 py-3 col-md-2 font-semibold text-white">Suggested Hours</br>යෝජිත පැය ගනන</td>
            <td scope="col" class="relative px-6 py-3 col-md-2 font-semibold text-white">Recommended Hours</br>අධ්‍යක්ෂ නිර්දේෂ කරන පැය ගනන</td>
          <?php endif; ?>

          <?php if((Auth::user()->user_level == 2) || (Auth::user()->user_level == 3) ||(Auth::user()->user_level == 4) || (Auth::user()->user_level == 5) ): ?>
           
            <td scope="col" class="relative px-6 py-3 col-md-2 font-semibold text-white">Suggested Hours</br>යෝජිත පැය ගනන</td>
            <td scope="col" class="relative px-6 py-3 col-md-2 font-semibold text-white">Recommended Hours</br>අධ්‍යක්ෂ නිර්දේෂ </br>කරන පැය ගනන</td>
            <?php if($this->param2=='r2'): ?>
              <td scope="col" class="relative px-6 py-3 col-md-2 font-semibold text-white">Approved OT Hours</br>අධ්‍යක්ෂ (පාලන) අනුමත</br> කරන පැය ගනන</td>
            <?php elseif($this->param2=='r3'): ?>
              <td scope="col" class="relative px-6 py-3 col-md-2 font-semibold text-white">Approved OT Hours</br>අ.අ.ජ (පාලන) අනුමත</br> කරන පැය ගනන</td>
            <?php endif; ?>

          <?php endif; ?>

          

          <th scope="col" class="relative px-6 py-3 col-md-2 text-white">ACTION</th>
        </tr>
      </thead>
      <tbody class="bg-white divide-y divide-sky-500">
          <div class="hidden"> <?php echo e($c=1); ?></div> 
          <?php $__currentLoopData = $otrecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->mark==1): ?>
              <tr class="bg-red-300">
            <?php else: ?>
              <tr >
            <?php endif; ?>

              <td class="px-6 py-2 align-top whitespace-nowrap text-sky-800"><?php echo e($c); ?></td><div class="hidden"> <?php echo e($c++); ?></div> 
              <td class=" whitespace-nowrap text-sky-800"><textarea class="border-none resize-y bg-transparent"  name="" id="" cols="15" rows="3"><?php echo e($item->name); ?></textarea></td>
              <td class="  whitespace-nowrap text-sky-800"><textarea class="border-none resize-y bg-transparent"  name="" id="" cols="10" rows="3"><?php echo e($item->desig); ?></textarea></td>
              <td class=" whitespace-nowrap text-sky-800"><textarea class="border-none resize-y bg-transparent"  name="" id="" cols="30" rows="3"><?php echo e($item->Nature_of_duties); ?></textarea></td>

              <?php if((Auth::user()->user_level == 8) || (Auth::user()->user_level == 7)|| (Auth::user()->user_level == 11)): ?>
                <td class="py-2 align-top whitespace-nowrap text-center text-sky-800"><?php echo e($item->suggest_ot_hour); ?></td> 
              <?php endif; ?>

              <?php if((Auth::user()->user_level == 6) ): ?>
                <td class="py-2 align-top whitespace-nowrap text-center text-sky-800"><?php echo e($item->suggest_ot_hour); ?></td> 
                <td class="py-2 align-top whitespace-nowrap text-center text-sky-800"><?php echo e($item->director_rec_ot_hour); ?></td> 
              <?php endif; ?>

              <?php if((Auth::user()->user_level == 2) ||(Auth::user()->user_level == 3) ||(Auth::user()->user_level == 4) || (Auth::user()->user_level == 5) ): ?>
                <td class="py-2 align-top whitespace-nowrap text-center text-sky-800"><?php echo e($item->suggest_ot_hour); ?></td> 
                <td class="py-2 align-top whitespace-nowrap text-center text-sky-800"><?php echo e($item->director_rec_ot_hour); ?></td> 
                <td class="py-2 align-top whitespace-nowrap text-center text-sky-800"><?php echo e($item->director_admin_rec_ot_hour); ?></td> 
              <?php endif; ?>
  
              <td class="px-6  text-right text-sm">

                <?php if($param1==1): ?>                  
                  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                  <?php if(Auth::user()->user_level == 8): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300']); ?>Delete <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                  <?php endif; ?> 
                <?php else: ?>
                  <?php if(Auth::user()->user_level != 5 && Auth::user()->user_level != 4): ?>
                    <!--<input type="checkbox"  wire:model="checkbox"><?php echo e(var_export($checkbox1)); ?>-->
                    <?php if($item->mark==1): ?>
                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-sky-600 border border-white w-25 text-center','wire:click' => 'highlight('.e($item->otid).')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-sky-600 border border-white w-25 text-center','wire:click' => 'highlight('.e($item->otid).')']); ?>Uncheck <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php else: ?>
                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-sky-600 border border-white w-25 text-center','wire:click' => 'highlight('.e($item->otid).')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-sky-600 border border-white w-25 text-center','wire:click' => 'highlight('.e($item->otid).')']); ?>Check <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php endif; ?>
                  <?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-sky-600 border border-white w-20 text-center','wire:click' => 'showEditOtRecordModel('.e($item->otid).')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-sky-600 border border-white w-20 text-center','wire:click' => 'showEditOtRecordModel('.e($item->otid).')']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                  <?php if(Auth::user()->user_level == 8): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-red-700 border border-white w-20 text-center','wire:click' => 'ShowDeleteModal('.e($item->otid).')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-red-700 border border-white w-20 text-center','wire:click' => 'ShowDeleteModal('.e($item->otid).')']); ?>Delete <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                  <?php endif; ?>
                <?php endif; ?>

                
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    
                  <div class="px-3 py-3 bg-sky-800 text-2xl rounded-bl-lg rounded-br-lg">
                    <?php echo e($otrecords->links()); ?>

                  </div>



                  <div class="m-2 p-2 border-2 border-gray-300 bg-gray-200 text-sky-700">
                    Minutes Sheet
                            <div class="hidden"> 
                              <?php echo e($minute=DB::table("minutes")
                              ->select('name','designation','minutes.updated_at as updated_at','minute','type','submit_level')
                              ->join('users','users.id','=','minutes.user')
                              ->join('user_designation','user_designation.id','=','users.designation_id')
                              //->join('user_level','user_level.user_level','=','users.user_level')
                              ->where('ot_list_number', '=', $param3 )
                              
                              ->orderBy('minutes.id', 'ASC')
                              ->get()); ?>

                            </div> 

                            <!--
                              F-forward
                              B-backward
                              A-Approve
                            -->
                            <div class=" text-justify   p-1 text-sm  ">                         
                              <?php $__currentLoopData = $minute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(($mn->type=="F") || ($mn->type=="A")): ?>
                                  <div class="text-green-700">
                                      <?php if($loop->first): ?> 
                                        <?php echo e($mn->updated_at); ?> -Create and Submitted by <?php echo e($mn->name); ?>(<?php echo e($mn->designation); ?>). <?php if($mn->minute<>""): ?> Remarks - <?php echo e($mn->minute); ?> <?php endif; ?><br>
                                      <?php elseif(($loop->last) && (($mn->submit_level==7) || ($mn->submit_level==3)) && ($mn->type=="A")): ?>
                                      <?php echo e($mn->updated_at); ?> - Approved by <?php echo e($mn->name); ?>(<?php echo e($mn->designation); ?>). <?php if($mn->minute<>""): ?> Remarks - <?php echo e($mn->minute); ?> <?php endif; ?><br>
                                      <?php else: ?>
                                        <?php echo e($mn->updated_at); ?> - Forwarded by <?php echo e($mn->name); ?>(<?php echo e($mn->designation); ?>). <?php if($mn->minute<>""): ?> Remarks - <?php echo e($mn->minute); ?> <?php endif; ?><br>
                                      <?php endif; ?>                                  
                                  </div>                        
                                <?php endif; ?>

                                <div class="text-orange-600">    
                                <?php if($mn->type=="B"): ?>
                                    <?php echo e($mn->updated_at); ?> - Resubmitted by <?php echo e($mn->name); ?>(<?php echo e($mn->designation); ?>). <?php if($mn->minute<>""): ?> Remarks - <?php echo e($mn->minute); ?> <?php endif; ?><br>
                                <?php endif; ?>
                                </div>                                
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                  </div>

  <br><br>
  </div>              





              <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'showingOtRecordModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'showingOtRecordModal']); ?>
                
                <?php if($isEditMode): ?>
                   <?php $__env->slot('title', null, []); ?> Update Record <?php $__env->endSlot(); ?>
                <?php else: ?>
                   <?php $__env->slot('title', null, []); ?> Create New Record <?php $__env->endSlot(); ?>
                <?php endif; ?> 
            
                 <?php $__env->slot('content', null, []); ?> 
                  <div>
                    <form enctype="multipart/form-data">
                      <div class="sm:col-span-6">
                        <label for="Emp_id" class="block text-sm font-medium text-sky-800"> Employee / නිලධාරියාගේ නම </label>                        
                        <div class="mt-1">                          
                            <?php if($isEditMode==1): ?> 
                                <div class="hidden"><input type="text" id="Emp_id"  wire:model.lazy="Emp_id" class="hidden"> </div> 
                                <?php $__currentLoopData = \App\Models\Employees::where('id','=',$this->Emp_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <input type="text" value="<?php echo e($data->name); ?>" disabled   class="cursor-not-allowed shadow-sm focus:ring-indigo-500 appearance-none bg-white border border-sky-800 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out focus:border-indigo-500 block w-full sm:text-sm ">                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                              
                            <?php else: ?>
                              <select name="Emp_id"  wire:model.lazy="Emp_id" class="text-sky-800 block mt-1 w-full border-gray-300 focus:border-sky-300 focus:ring focus:ring-sky-200 focus:ring-opacity-50 rounded-md shadow-sm">
                                <option></option>
                                <?php $__currentLoopData = \App\Models\Employees::where('institute','=',Auth::user()->institute)->orderBy('name','ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                            <?php endif; ?>                          
                        </div>
                        <?php $__errorArgs = ['Emp_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
  
                      

                      <?php if((Auth::user()->user_level == 8) || (Auth::user()->user_level == 7)|| (Auth::user()->user_level == 11)): ?>                      
                          <div class="sm:col-span-6 pt-5">
                            <label for="suggest_ot_hour" class="block text-sm font-medium text-sky-800">Suggested OT Hours - යෝජිත පැය ගනන</label>
                            <div class="mt-1">
                              <input type="text" id="suggest_ot_hour"  wire:model.lazy="suggest_ot_hour" wire:change="showmsg" class="text-sky-800 shadow-sm focus:ring-sky-200 appearance-none bg-white border border-sky-800 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out focus:border-sky-500 block w-full sm:text-sm ">
                            </div>
                            
                            
                            <?php $__errorArgs = ['suggest_ot_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                      <?php endif; ?>

                      <?php if((Auth::user()->user_level == 6) ): ?>
                          <div class="sm:col-span-6 pt-5">
                            <label for="director_rec_ot_hour" class="block text-sm font-medium text-sky-800">OT Hours Recomend by Director - අධ්‍යක්ෂ නිර්දේෂ/අනුමත කරන පැය ගනන</label>
                            <div class="mt-1">
                              <input type="text" id="director_rec_ot_hour"  wire:model.lazy="director_rec_ot_hour" class="shadow-sm focus:ring-indigo-500 appearance-none bg-white border border-sky-800 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out focus:border-indigo-500 block w-full sm:text-sm ">
                            </div>
                            <?php $__errorArgs = ['director_rec_ot_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                      <?php endif; ?>

                      <?php if((Auth::user()->user_level == 2) ||(Auth::user()->user_level == 3) ||(Auth::user()->user_level == 4) || (Auth::user()->user_level == 5) ): ?>
                          <div class="sm:col-span-6 pt-5">
                            <label for="director_admin_rec_ot_hour" class="block text-sm font-medium text-sky-800">Approved OT Hours- අ.අ.ජ (පාලන) අනුමත කරන පැය ගනන</label>
                            <div class="mt-1">
                              <input type="text" id="director_admin_rec_ot_hour"  wire:model.lazy="director_admin_rec_ot_hour" class="shadow-sm focus:ring-indigo-500 appearance-none bg-white border border-sky-800 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out focus:border-indigo-500 block w-full sm:text-sm ">
                            </div>
                            <?php $__errorArgs = ['director_admin_rec_ot_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                      <?php endif; ?>

                      <div class="sm:col-span-6 pt-5">
                        <label for="Nature_of_duties" class="block text-sm font-medium text-sky-800">Nature of Duties / රාජකාරී ස්වභාවය</label>
                        <div class="mt-1">
                          <textarea id="Nature_of_duties" rows="3" wire:model.lazy="Nature_of_duties" class="text-sky-800 shadow-sm focus:ring-sky-200 appearance-none bg-white border border-sky-800 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out focus:border-sky-500 block w-full sm:text-sm "></textarea>
                        </div>
                        <?php $__errorArgs = ['Nature_of_duties'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                     </form>
                  </div>
                  <input type="text" id="msg" wire:model.lazy="msg" disabled class="text-orange-700 text-2xl border-hidden  py-2 px-3  block w-full sm:text-sm shadow-none  focus:border-hidden">
                 <?php $__env->endSlot(); ?>

                 <?php $__env->slot('footer', null, []); ?>               
                  <?php if($isEditMode): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'editOtRec('.e($param).')','class' => 'bg-sky-800 hover:bg-sky-600 border border-white']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'editOtRec('.e($param).')','class' => 'bg-sky-800 hover:bg-sky-600 border border-white']); ?>Update <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                  <?php else: ?>               
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'storeOtRecords('.e($param).')','class' => 'bg-sky-800 hover:bg-sky-600 border border-white']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'storeOtRecords('.e($param).')','class' => 'bg-sky-800 hover:bg-sky-600 border border-white']); ?>Create <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                  <?php endif; ?>   
                 <?php $__env->endSlot(); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


            <div>
              <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'showingdeletemodal','class' => ' z-50 bg-opacity-100']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'showingdeletemodal','class' => ' z-50 bg-opacity-100']); ?>
                 <?php $__env->slot('title', null, []); ?>  <?php $__env->endSlot(); ?>
        
                 <?php $__env->slot('content', null, []); ?> 
    
                <div class="text-center">
                  <label for="designation" class="block text-xl font-medium text-gray-700"> Are you sure you want to delete this record?</label>  
                </div>
    
                <input type="text" id="deleteID" wire:model.lazy="deleteID" name="deleteID" class="hidden block w-full transition duration-150 ease-in-out appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
        
                <div class="text-center p-6 "> 
                  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'DeleteModal','class' => 'bg-black-300 hover:bg-red-500']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'DeleteModal','class' => 'bg-black-300 hover:bg-red-500']); ?>Yes <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>        
                  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'HideDeleteModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'HideDeleteModal']); ?>No <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
    
                 <?php $__env->endSlot(); ?>
          
                 <?php $__env->slot('footer', null, []); ?>  <?php $__env->endSlot(); ?>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>








            <div>
              <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'showingforwardmodal','class' => ' z-50 bg-opacity-100']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'showingforwardmodal','class' => ' z-50 bg-opacity-100']); ?>
                 <?php $__env->slot('title', null, []); ?>  <?php $__env->endSlot(); ?>
              
                 <?php $__env->slot('content', null, []); ?> 
          

                  <div class=' py-5  h-36'>
                    <div class="">
                      <label for="designation" class="block text-xl font-medium text-sky-800"> Minute </label> 
                    </div>
                    <div class="w-full">
                      <textarea rows=4 cols="10" id="minute" wire:model.lazy="minute" name="minute" class=" w-full appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" ></textarea>
                    <?php $__errorArgs = ['minute'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
          
                  <div class="text-right py-5">
                    <!-- 8 -->
          
                     
                        <div class="hidden"><?php echo e($otrec=DB::table("ot_list_status")->select('id','List_id','ot_range')->where('List_id', '=', $this->param )->where('ot_range', '=', $this->param2 )->get()); ?></div>   
                        <div class="hidden"><?php echo e($otrec1=DB::table("ot_records")->where('List_id', '=', $this->param )->where('ot_range', '=', $this->param2 )->get()); ?></div>                                    
                        
                            <?php $__currentLoopData = $otrec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <?php if($otrec1->count()==0): ?>
                                  <?php if((Auth::user()->user_level==6)||(Auth::user()->user_level==3)||(Auth::user()->user_level==2)): ?> 
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300 mr-14']); ?>Approve <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                  <?php else: ?>
                                  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-gray-700 hover:bg-gray-700 text-gray-300 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                  <?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'HideSubmitModal','class' => 'bg-sky-800 hover:bg-sky-600']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'HideSubmitModal','class' => 'bg-sky-800 hover:bg-sky-600']); ?>Cancel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php else: ?> 
                                    <?php if((Auth::user()->user_level==11)): ?>
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'Submit11(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'Submit11(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php elseif((Auth::user()->user_level==10)): ?>
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'Submit10(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'Submit10(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php elseif((Auth::user()->user_level==9)): ?>
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'Submit9(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'Submit9(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php elseif((Auth::user()->user_level==8)): ?>
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'Submit8(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'Submit8(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php elseif((Auth::user()->user_level==7)): ?> 
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'Submit7(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'Submit7(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php elseif((Auth::user()->user_level==6)): ?> 
                                          <?php if($this->param2=='r1'): ?> <!-- check OT Range -->
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-sky-600','wire:click' => 'approve_Director(\''.e($item->id).'\')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-sky-600','wire:click' => 'approve_Director(\''.e($item->id).'\')']); ?>Approve <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                                          <?php else: ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'Submit6(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'Submit6(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                          <?php endif; ?>
                                    <?php elseif((Auth::user()->user_level==5)): ?> 
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'Submit5(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'Submit5(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php elseif((Auth::user()->user_level==4)): ?> 
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'Submit4(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'Submit4(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php elseif(Auth::user()->user_level==3): ?> 
                                          <?php if($this->param2=='r2'): ?> <!-- check OT Range -->
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-sky-600','wire:click' => 'approve_Director_Admin(\''.e($item->id).'\')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-sky-600','wire:click' => 'approve_Director_Admin(\''.e($item->id).'\')']); ?>Approve <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                                          <?php else: ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'Submit3(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'Submit3(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Forward <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                          <?php endif; ?>
                                    <?php elseif(Auth::user()->user_level==2): ?>
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'approve_ADG(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'approve_ADG(\''.e($item->id).'\')','class' => 'bg-sky-800 hover:bg-sky-600 mr-14']); ?>Approve <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php endif; ?> 
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'HideForwardModal','class' => 'bg-sky-800 hover:bg-sky-600']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'HideForwardModal','class' => 'bg-sky-800 hover:bg-sky-600']); ?>Cancel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                              
                     
                    
                  
                

                        
             
                  </div>

                 <?php $__env->endSlot(); ?>
                
                 <?php $__env->slot('footer', null, []); ?> 
          
                 <?php $__env->endSlot(); ?>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>






            <div>
              <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'showingResubmitmodal','class' => ' z-50 bg-opacity-100']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'showingResubmitmodal','class' => ' z-50 bg-opacity-100']); ?>
                 <?php $__env->slot('title', null, []); ?>  <?php $__env->endSlot(); ?>
              
                 <?php $__env->slot('content', null, []); ?> 
          

                  <div class=' py-5 h-36'>
                    <div class="">
                      <label for="designation" class="block text-xl font-medium text-sky-800"> Minute </label> 
                    </div>
                    <div class="w-full">
                      <textarea rows=4 cols="13" id="minute" wire:model.lazy="minute" name="minute" class=" w-full appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" ></textarea>
                    <?php $__errorArgs = ['minute'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
          
                  <div class="text-right">
                    <!-- 8 -->
          
                     
                        <div class="hidden"><?php echo e($otrec=DB::table("ot_list_status")->select('id','List_id','ot_range')->where('List_id', '=', $this->param )->where('ot_range', '=', $this->param2 )->get()); ?></div>   
                        <div class="hidden"><?php echo e($otrec1=DB::table("ot_records")->where('List_id', '=', $this->param )->where('ot_range', '=', $this->param2 )->get()); ?></div>                                    
                        
                            <?php $__currentLoopData = $otrec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                
                                    
                                    <?php if((Auth::user()->user_level==7)): ?> 
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'ReSubmit7(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'ReSubmit7(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']); ?>ReSubmit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php elseif((Auth::user()->user_level==6)): ?> 
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'ReSubmit6(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'ReSubmit6(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']); ?>ReSubmit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>    
                                    <?php elseif((Auth::user()->user_level==5)): ?> 
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'ReSubmit5(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'ReSubmit5(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']); ?>ReSubmit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php elseif((Auth::user()->user_level==4)): ?> 
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'ReSubmit4(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'ReSubmit4(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']); ?>ReSubmit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php elseif(Auth::user()->user_level==3): ?> 
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'ReSubmit3(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'ReSubmit3(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']); ?>ReSubmit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php elseif(Auth::user()->user_level==2): ?>
                                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'ReSubmit2(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'ReSubmit2(\''.e($item->id).'\')','class' => 'bg-orange-400 hover:bg-orange-600 mr-14']); ?>ReSubmit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php endif; ?> 
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'HideResubmitModal','class' => 'bg-sky-800 hover:bg-sky-600']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'HideResubmitModal','class' => 'bg-sky-800 hover:bg-sky-600']); ?>Cancel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                              
                     
                    
                  
                

                        
             
                  </div>

                 <?php $__env->endSlot(); ?>
                
                 <?php $__env->slot('footer', null, []); ?> 
          
                 <?php $__env->endSlot(); ?>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
  
</div>





  <?php /**PATH D:\Laravel Project\Laravel9\OT\OT SYS 20221216\resources\views/livewire/otrecords.blade.php ENDPATH**/ ?>