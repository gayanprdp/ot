


<div>
  



    <div class="grid grid-cols-2 p-3 bg-white" >
      <div>
        <h2 class="font-semibold text-xl text-sky-800 leading-tight">
          <?php echo e(__('OT Sheets Status')); ?>

        </h2>
        <div aligne="left" class=" py-3 text-left text-sky-700 dark:text-gray-300 uppercase tracking-wider"> 
          <?php if(Auth::user()->user_level>6): ?>
            <?php $__currentLoopData = $ins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                <td class="px-6 py-4 whitespace-nowrap"><?php echo e($item1->institute); ?></td>                        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
      </div>
      </div>
      <div>
        <div class="flex justify-end m-2 ">  
          <input data-bs-toggle="tooltip" data-bs-placement="top" title="Search with Institute , Year or Month" type="search" wire:click="gotoPage(1)" wire:model="search" placeholder="Search...  " class="block  transition duration-150 ease-in-out appearance-none bg-white border border-sky-700 w-64 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5">
        </div>
      </div>
    </div>

    <div class="max-w mx-auto px-2 bg-white">

      <div class="grid grid-cols-2  bg-white pb-2" > 
        
        <div class="p-1 text-sky-700 ">Year / අවුරුද්ද<br>
          <div class="hidden">
            <?php echo e($c=now()->year); ?>

          </div>        
          <select name="year"  wire:model.lazy="year" class="w-full  border-sky-700 rounded-md focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 shadow-sm">
            <option value="">All</option>
            <?php for($x=1;$x<10;$x++): ?>
                <option value="<?php echo e($c); ?>"><?php echo e($c); ?></option>
                <div class="hidden">
                  <?php echo e($c--); ?>

                </div>                
              <?php endfor; ?>
          </select>
        </div>
        
        <div class="p-1 text-sky-700 ">Status<br> 
          <select name="status"  wire:model.lazy="status" class="w-full  border-sky-700 rounded-md focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 shadow-sm">
            <option value="I">Incomplete</option>
            <option value="C">Completed</option>
            <option value="A">All</option>
          </select>
        </div>

        
      </div>
      

      <?php if(Auth::user()->user_level<=8): ?>
      <div class="p-1 pb-5  text-sky-700">
      Institute / ආයතනය<br>
          <select name="institute"  wire:model.lazy="institute" class="w-full border-sky-700 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm">
              <option></option>
                <?php if(Auth::user()->user_level==8 || Auth::user()->user_level==7 || Auth::user()->user_level==6): ?>
                    <?php $__currentLoopData = \App\Models\institute::where('main_institute','=',Auth::user()->institute)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($data->id); ?>"><?php echo e($data->institute); ?> - (<?php echo e($data->institute_code); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <?php else: ?>
                    <?php $__currentLoopData = \App\Models\institute::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($data->id); ?>"><?php echo e($data->institute); ?> - (<?php echo e($data->institute_code); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <?php endif; ?>
          </select>
      </div>
      <?php endif; ?>
                  

                 

  
  
      <table  class="w-full divide-y divide-sky-700"  width="100%">
        <div class="bg-sky-800 text-sky-800 dark:bg-gray-600 dark:text-gray-200 rounded-tl-lg rounded-tr-lg h-2">.  </div>
        <thead class="bg-sky-800 dark:bg-gray-600 dark:text-gray-200 rounded-tl-lg">
          <tr>
            <th scope="col"  class=" w-1  text-white p-1">Index</th>
            <th scope="col"  class=" w-24 text-white p-1">Year</br>අවුරුද්ද</th>
            <th scope="col"  class=" w-32 text-white p-1">Month</br>මාසය  </th>
            <th scope="col"  class=" w-36 text-white">Sheet Type  </th>
            <th scope="col"  class=" w-32 text-white p-1"></th>
            <?php if(Auth::user()->user_level<=8): ?>
              <th scope="col"  class=" w-32 text-white p-1">Institute</br>ආයතනය </th>
            <?php endif; ?>
            
            <th scope="col"  class=" w-1/3 text-white p-1">Status</br> </th>
            <th scope="col"  class=" w-32"></th>
          </tr>
        </thead>
        
        <tbody class="bg-white divide-y divide-sky-500">
                               
        

                       

        <?php $__currentLoopData = $otlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="hidden">
          <?php echo e($ot_rec_check=DB::table("ot_records")
          ->select('List_id','ot_range')
          ->where('List_id', '=', $item->id )
          ->where('ot_range', '=', $item->ot_range)
          ->count()); ?>   
          </div> 


        <?php if(($ot_rec_check!=0) || ($item->ot_range=='r1') ): ?>
          <tr>
            <td valign="top" class="px-6 py-5 whitespace-nowrap text-sky-800"><?php echo e($otlist->firstItem()+$key); ?></td>
              
                                      
            <td valign="top" class="px-6 py-5 whitespace-nowrap text-sky-800"><?php echo e($item->year); ?></td>
            <td valign="top" class="px-6 py-5 whitespace-nowrap text-sky-800"><?php echo e($item->month); ?></td>
            
            <?php if($item->type==0): ?>
              <td valign="top" class="px-6 py-5 whitespace-nowrap  text-sky-800">Pre</td>
            <?php else: ?>
              <td valign="top" class="px-6 py-5 whitespace-nowrap  text-sky-800">Post</td>
            <?php endif; ?>

            <?php if($item->ot_range=='r1'): ?>
              <td valign="top" class="px-6 py-5 whitespace-nowrap  text-sky-800">For Director Approval </td>
            <?php elseif($item->ot_range=='r2'): ?>
              <td valign="top" class="px-6 py-5 whitespace-nowrap  text-sky-800">For Director- Admin Approval </td>
            <?php elseif($item->ot_range=='r3'): ?>
              <td valign="top" class="px-6 py-5 whitespace-nowrap  text-sky-800">For ADG Approval </td>
            <?php endif; ?>
            <?php if(Auth::user()->user_level<=8): ?>
              <td valign="top" class="px-6 py-3 whitespace-nowrap text-sky-800 " title="<?php echo e($item->institute); ?>"><?php echo e($item->institute_code); ?> - <?php echo e($item->institute); ?></td>
            <?php endif; ?>

            

            <td valign="top" class="px-6 py-3 whitespace-nowrap text-sky-800">
                                        <?php if($item->L2=='1'): ?>
                                            
                                              <p class="text-sky-800 text-sm p-1">Completed </p>
                                              <div class="w-full bg-gray-300 h-2 rounded-xl">
                                                <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:100%">                                                
                                                </div>
                                              </div> 
                                            
                                        <?php elseif($item->L3=='1' && $item->completed=='0'): ?>
                                            
                                            
                                            <p class="text-sky-800 text-sm p-1">Pending Additional Director General(Admin) Approval </p>

                                            <div class="w-full bg-gray-300 h-2 rounded-xl">
                                              <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:90%">
                                              </div>
                                            </div> 
                                        <?php elseif($item->L3=='1' && $item->completed=='1'): ?>
                                            
                                            
                                            <p class="text-sky-800 text-sm p-1">Completed </p>
                                            <div class="w-full bg-gray-300 h-2 rounded-xl">
                                              <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:100%">                                                
                                              </div>
                                            </div>    
                                            
                                        <?php elseif($item->L4=='1'): ?>
                                            
                                            <p class="text-sky-800 text-sm p-1">Pending Director(Admin) Approval </p>

                                            
                                            <div class="w-full bg-gray-300 h-2 rounded-xl">
                                              <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:80%">
                                              </div>
                                            </div> 
                                            
                                            
                                            
                                        <?php elseif($item->L5=='1'): ?>
                                            
                                            <p class="text-sky-800 text-sm p-1">Pending AO/CC(Admin) Review</p>

                                            <div class="w-full bg-gray-300 h-2 rounded-xl">
                                              <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:70%">
                                              </div>
                                            </div> 
                                            
                                           

                                        <?php elseif($item->L6=='1'): ?>
                                            <?php if($item->completed=='1'): ?>
                                                <p class="text-sky-800 text-sm p-1">Completed</p>                                              
                                                <div class="w-full bg-gray-300 h-2 rounded-xl">
                                                  <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:100%">
                                                  </div>
                                                </div> 
                                            <?php else: ?>
                                              <p class="text-sky-800 text-sm p-1">Pending Subject Officer(Admin) Review </p>

                                              <div class="w-full bg-gray-300 h-2 rounded-xl">
                                                <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:60%">
                                                </div>
                                              </div> 
                                             <?php endif; ?>   
                                            
                                        <?php elseif($item->L7=='1'): ?>
                                            
                                            
                                              <p class="text-sky-800 text-sm p-1">Pending Director/CE/CA Review/Approval </p>                                              
                                              <div class="w-full bg-gray-300 h-2 rounded-xl">
                                                <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:50%">
                                                </div>
                                              </div> 
                                            
                                            
                                            
                                        <?php elseif($item->L8=='1'): ?>
                                            
                                            <p class="text-sky-800 text-sm p-1">Pending AO/CC (Director Office) Review </p>

                                           <div class="w-full bg-gray-300 h-2 rounded-xl">
                                              <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:40%">
                                              </div>
                                            </div> 
                                            
                                            
                                        <?php elseif($item->L9=='1'): ?>
                                            
                                            <p class="text-sky-800 text-sm p-1">Pending Subject Officer (Director Office) Review </p>

                                           <div class="w-full bg-gray-300 h-2 rounded-xl">
                                              <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:30%">
                                              </div>
                                            </div> 
                                            
                                        <?php elseif($item->L10=='1'): ?>
                                            
                                            <p class="text-sky-800 text-sm p-1">Pending AD/DD  Review </p>

                                           <div class="w-full bg-gray-300 h-2 rounded-xl">
                                              <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:20%">
                                              </div>
                                            </div> 
                                            
                                        <?php elseif($item->L11=='1'): ?>
                                            
                                            <p class="text-sky-800 text-sm p-1">Pending AO/CC Review </p>

                                           <div class="w-full bg-gray-300 h-2 rounded-xl">
                                              <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:10%">
                                              </div>
                                            </div> 
                                            
                                                

                                        <?php else: ?>
                                            <p class="text-sky-800 text-sm p-1">OT Sheet Created</p>
                                            <div class="w-full bg-gray-300 h-2 rounded-xl">
                                              <div class="bg-green-500 h-2 p-1 rounded-xl" style="width:3%">
                                                
                                              </div>
                                            </div> 
                                        <?php endif; ?>                                        
            </td>

            <td class="text-right text-sm">    
              <div class="py-1">
              <?php if($item->completed=='1'): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-sky-600','wire:click' => 'printotrecords('.e($item->id).',\''.e($item->ot_range).'\')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-sky-600','wire:click' => 'printotrecords('.e($item->id).',\''.e($item->ot_range).'\')']); ?>Print <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
              <?php endif; ?>
              
              <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-sky-600 mt-1','wire:click' => 'viewotrecords('.e($item->id).',1,\''.e($item->ot_range).'\',\''.e($item->otlistid).'\',\''.e($item->type).'\')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-sky-600 mt-1','wire:click' => 'viewotrecords('.e($item->id).',1,\''.e($item->ot_range).'\',\''.e($item->otlistid).'\',\''.e($item->type).'\')']); ?>View <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <div class="px-3 py-3 bg-sky-800 text-2xl rounded-bl-lg rounded-br-lg">
        <?php echo e($otlist->links()); ?>

      </div>

      <div class="m-2 p-2"></div>
               
    </div>              

 

      

<div>
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'showingOtListModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'showingOtListModal']); ?>
              
         
          <?php if($isEditMode): ?>
           <?php $__env->slot('title', null, []); ?> Update Institute <?php $__env->endSlot(); ?>
          <?php else: ?>
           <?php $__env->slot('title', null, []); ?> Create New OT Sheet <?php $__env->endSlot(); ?>
          <?php endif; ?>  
              
                 
              

          
           <?php $__env->slot('content', null, []); ?> 
              <div >
                  <form enctype="multipart/form-data">

                    <div class="sm:col-span-6">
                      <label for="year" class="block text-sm font-medium text-gray-700"> Year / අවුරුද්ද</label>
                      <div class="mt-1">
                      

                        <?php $c=now()->year?> 
                        

                        <select name="year"  wire:model.lazy="year" class=" block mt-1 w-full border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm">
                          <option></option>
                          <?php for($x=1;$x<6;$x++): ?>
                            <option value="<?php echo e($c); ?>"><?php echo e($c); ?></option>
                            <?php $c--?> 
                          <?php endfor; ?>
                                                       

                        </select>
                        
                      </div>
                      <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="sm:col-span-6">
                      <label for="month" class="block text-sm font-medium text-gray-700"> Month / මාසය</label>
                      <div class="mt-1">
                     
                        <select name="month"  wire:model.lazy="month" class=" block mt-1 w-full border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm">
                          <option></option>
                          
                              <option value="January">January</option>
                              <option value="February">February</option>
                              <option value="March">March</option>  
                              <option value="April">April</option>
                              <option value="May">May</option>
                              <option value="June">June</option>    
                              <option value="July">July</option>   
                              <option value="August">August</option>   
                              <option value="September">September</option>   
                              <option value="October">October</option>   
                              <option value="November">November</option>   
                              <option value="Dicember">Dicember</option>                         

                        </select>
                        
                      </div>
                      <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
         
                    
                  </form>
                </div>
                


           <?php $__env->endSlot(); ?>
           <?php $__env->slot('footer', null, []); ?> 
              
              <?php if($isEditMode): ?>
              <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'editIns']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'editIns']); ?>Update <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
              <?php else: ?>
              <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'storeOtList('.e(Auth::user()->institute).')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'storeOtList('.e(Auth::user()->institute).')']); ?>Create <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
              <?php endif; ?>   
             
             <?php $__env->endSlot(); ?>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>



<div>
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'showingdeletemodal','class' => ' z-50 bg-opacity-100']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'showingdeletemodal','class' => ' z-50 bg-opacity-100']); ?>
       <?php $__env->slot('title', null, []); ?>  <?php $__env->endSlot(); ?>
    
       <?php $__env->slot('content', null, []); ?> 

        <div class="text-center">
          <label for="designation" class="block text-xl font-medium text-gray-700"> Are you sure you want to delete this record?</label>  
        </div>

        <input type="text" id="deleteID" wire:model.lazy="deleteID" name="deleteID" class="hidden block w-full transition duration-150 ease-in-out appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
    
        <div class="text-center p-6 "> 
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'DeleteModal','class' => 'bg-black-300 hover:bg-red-500']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'DeleteModal','class' => 'bg-black-300 hover:bg-red-500']); ?>Yes <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>        
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'HideDeleteModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'HideDeleteModal']); ?>No <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>

       <?php $__env->endSlot(); ?>
      
       <?php $__env->slot('footer', null, []); ?>  <?php $__env->endSlot(); ?>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>



<div>
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'showingsubmitmodal','class' => ' z-50 bg-opacity-100']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'showingsubmitmodal','class' => ' z-50 bg-opacity-100']); ?>
       <?php $__env->slot('title', null, []); ?>  <?php $__env->endSlot(); ?>
    
       <?php $__env->slot('content', null, []); ?> 

        <div class="text-center">
          <label for="designation" class="block text-xl font-medium text-gray-700"> Are you sure you want to submit this record?</label>  
        </div>

        <input type="text" id="deleteID" wire:model.lazy="deleteID" name="deleteID" class="hidden block w-full transition duration-150 ease-in-out appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
    
        <div class="text-center p-6 "> 
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'SubmiModal','class' => 'bg-black-300 hover:bg-red-500']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'SubmiModal','class' => 'bg-black-300 hover:bg-red-500']); ?>Yes <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>        
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'HideSubmitModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'HideSubmitModal']); ?>No <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>

       <?php $__env->endSlot(); ?>
      
       <?php $__env->slot('footer', null, []); ?>  <?php $__env->endSlot(); ?>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>


</div>



<?php /**PATH D:\Laravel Project\Laravel9\OT\OT SYS 20230217\resources\views/livewire/otlist_status.blade.php ENDPATH**/ ?>