

<div>
    
    
    <div class="max-w-6xl mx-auto">
        <?php $__currentLoopData = $otlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="flex justify-end m-2 p-2">          
            <button onclick="window.print()" class="print:hidden bg-sky-800 hover:bg-sky-600 mx-1 text-white py-2 px-4 rounded shadow hover:shadow-xl  duration-300">Print </button>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-sky-600 mx-1','wire:click' => 'back('.e($param).')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-sky-600 mx-1','wire:click' => 'back('.e($param).')']); ?>Back <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            
        </div>

        <div class="px-6 py-3 text-center text-gray-600 dark:text-gray-300 uppercase tracking-wider">
            <strong><?php echo e($param2); ?>අතිකාල අයදුම්පත -<?php echo e($item->year); ?> <?php echo e($item->month); ?> මාසය සදහා</strong>
        </div>
        <div class=" py-6 text-justify text-gray-600 dark:text-gray-300 uppercase tracking-wider">
            කෘෂිකර්ම දෙපාර්තමේන්තුවේ <strong><?php echo e($item->institute); ?> </strong>ට අනුයුක්තව සේවය කරන පහත නම් සදහන් නිලධාරීන්ගේ එක් එක් නම් ඉදිරියේන් දක්වා ඇති අතිකාල දීමනා ගෙවීම් පිලිබද නිර්දේශය පහත දක්වමි
        </div>


        <table  class="w-full divide-y divide-gray-200 border-solid" >
            

            <thead class="bg-gray-50 dark:bg-gray-600 dark:text-gray-200">
                <tr>
                    <td scope="col" class="px-1 text-center">1</td>
                    <td scope="col" class="px-1 text-center">2</td>
                    <td scope="col" class="px-1 text-center">3</td>
                    <td scope="col" class="px-1 text-center">4</td>
                    <td scope="col" class="px-1 text-center">5</td>
                    
                    <td scope="col" class="px-1">6</td>
                    <td scope="col" class="px-1">7</td>
                    
                  </tr>
              <tr>
                <td scope="col" class="px-1"><strong>අංක</strong></td>
                <td scope="col" class="px-1"><strong>නිලධාරියාගේ නම</strong> </td>
                <td scope="col" class="px-1"><strong>තනතුර</strong></td>
                <td scope="col" class="px-1"><strong>රාජකාරී ස්වභාවය</strong></td>
                <td scope="col" class="px-1"><strong>යෝජිත පැය ගනන</strong></td>
                
                <td scope="col" class="px-1"><strong>අධ්‍යක්ෂ නිර්දේෂ කරන පැය ගනන</strong></td>
                <td scope="col" class="px-1"><strong>අ.අ.ජ (පාලන) අනුමත කරන පැය ගනන</strong></td>
               
              </tr>
            </thead>
            
            <?php $c=1 ?>  

            <?php $__currentLoopData = $otrecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        
            <tr>
           
                <td class="px-2 py-1 whitespace-nowrap" valign='top'><?php echo e($c); ?></td>

                <?php $c++ ?> 
            <td class="px-2 py-1" valign='top'><?php echo e($item->name); ?></td>
            <td class="px-2 py-1" valign='top'><?php echo e($item->desig); ?></td>
            <td class="px-2 py-1" valign='top'><?php echo e($item->Nature_of_duties); ?></td>
            
            <td class="px-2 py-1 text-center" valign='top'><?php echo e($item->suggest_ot_hour); ?></td>
            <td class="px-2 py-1 text-center" valign='top'><?php echo e($item->director_rec_ot_hour); ?></td>
            <td class="px-2 py-1 text-center" valign='top'><?php echo e($item->director_admin_rec_ot_hour); ?></td>
            
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <div class=" py-6 text-justify text-gray-600 dark:text-gray-300 uppercase tracking-wider">
            ඉහත සදහන් පරිදි අතිකාල දීමනා නිර්දේශ කර ඉදිරිපත් කරන අතර අනුමැතිය ලබාදීමට අවශ්‍ය කටයුතු සලසා දෙන මෙන් කාරුණිකව ඉල්ලා සිටිමි.
        </div>


        
        
    </div>

     
</div>   


    
 
<style>
    table, th, td {
        border: 1px solid black;
       
       
      }

   
  </style>
<?php /**PATH D:\Laravel Project\Laravel9\OT\OT SYS 20221129\resources\views/livewire/print-o-t-rec.blade.php ENDPATH**/ ?>