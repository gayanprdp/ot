

<div>
  
 

  <div class="grid grid-cols-2 p-4 bg-white" >
    <div>
      <h2 class="font-semibold text-xl text-sky-700 leading-tight">
      <?php echo e(__('Manage Designations')); ?>

    </h2>

        <div aligne="left" class=" py-3 text-left text-sky-700 dark:text-gray-300 uppercase tracking-wider"> 
                    <?php if(Auth::user()->user_level!=1): ?>
                      <?php $__currentLoopData = $ins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                          <!--<td class="px-6 py-4 whitespace-nowrap"><?php echo e($item1->institute); ?></td> -->                       
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
        </div>
    </div>
    <div>
      <div class="flex justify-end m-2 p-2">
          
         <input type="search" wire:click="gotoPage(1)" wire:model="search" placeholder="Search..." class=" focus:border-sky-400 focus:ring focus:ring-sky-200 focus:ring-opacity-50 block w-64 text-sky-700 transition duration-150 ease-in-out appearance-none bg-white border border-sky-700 rounded-md py-2 px-3 text-base leading-normal sm:text-sm sm:leading-5">
                    
      </div>
      <div class="flex justify-end m-2 p-2"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'showDesModal','class' => 'bg-sky-800 hover:bg-sky-600 m-2']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'showDesModal','class' => 'bg-sky-800 hover:bg-sky-600 m-2']); ?>Create New Designation  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> </div>
      

    </div>
  </div>

  <div class="max-w mx-auto px-3 ">

                  


                
  
  
                  <table  class="w-full divide-y divide-sky-700">
                    <div class="bg-sky-800 text-sky-800 dark:bg-gray-600 dark:text-gray-200 rounded-tl-lg rounded-tr-lg h-2">.  </div>
                    <thead class="bg-sky-800 dark:bg-gray-600 dark:text-gray-200">
                      
                      <tr>
                        <th rowspan="2" scope="col" class="relative px-6 py-3   text-white">Designation</br> තනතුර</th>
                        <?php if(Auth::user()->user_level==0): ?>
                          <th scope="col" class="relative px-6 py-3  w-1/2 text-white">Institute</br>ආයතනය </th>
                        <?php endif; ?>
                        <th colspan="3" scope="col" class="relative px-6 py-3 text-white">OT Hours can Approve / අනුමත කල හැකි පැය ගනන</th>
                        <th  rowspan="2" scope="col" class="relative px-6 py-3 text-white">Action</th>
                      </tr>
                      
                      <tr>
                        
                        <?php if(Auth::user()->user_level==0): ?>
                          <th scope="col" class="relative px-6 py-3  w-1/2 text-white">Institute</br>ආයතනය </th>
                        <?php endif; ?>
                        <th scope="col" class="relative px-6 py-3 text-white">Director / අධ්‍යක්ෂ </th>
                        <th scope="col" class="relative px-6 py-3 text-white">Director -Admin / අධ්‍යක්ෂ පාලන </th>
                        <th scope="col" class="relative px-6 py-3 text-white">ADG / අතිරේක අධ්‍යක්ෂ ජනරාල් </th>
                        
                      </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-sky-500">
                      <tr></tr>
                      
                      
                                                  
                    <?php $__currentLoopData = $des; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                      <tr>
                      <td class="px-6 py-4 whitespace-nowrap text-sky-800 text-left"><?php echo e($item->designation1); ?></td>
                      <?php if(Auth::user()->user_level==0): ?>
                        <td class="px-6 py-4 whitespace-nowrap text-sky-800 text-left"><?php echo e($item->institute_code); ?> - <?php echo e($item->institute); ?></td>
                      <?php endif; ?>
                      <td class="px-6 py-4 whitespace-nowrap text-sky-800 text-center"><?php echo e($item->OT_range1); ?></td>
                      <td class="px-6 py-4 whitespace-nowrap text-sky-800 text-center"><?php echo e($item->OT_range2); ?></td>
                      <td class="px-6 py-4 whitespace-nowrap text-sky-800 text-center"><?php echo e($item->OT_range3); ?></td>
                      
  
  
                          
                      <td class="px-6 py-4 text-right text-sm text-sky-800">
                       
                        
                        
                        <!--
                        <?php if($confirming===$item->id): ?>
                        
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-red-400 hover:bg-red-500','wire:click' => 'kill('.e($item->id).')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-red-400 hover:bg-red-500','wire:click' => 'kill('.e($item->id).')']); ?>Sure? <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php else: ?>
                        
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-red-400 hover:bg-red-500','wire:click' => 'confirmDelete('.e($item->id).')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-red-400 hover:bg-red-500','wire:click' => 'confirmDelete('.e($item->id).')']); ?>Delete <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                        <?php endif; ?>
                        -->

                        <?php if($item->empdes == null): ?>  
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-red-700 border border-white w-20 text-center','wire:click' => 'ShowDeleteModal('.e($item->id).')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-red-700 border border-white w-20 text-center','wire:click' => 'ShowDeleteModal('.e($item->id).')']); ?>Delete <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                        <?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'bg-sky-800 hover:bg-sky-600 border border-white w-20 text-center','wire:click' => 'showEditDesModel('.e($item->id).')']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-800 hover:bg-sky-600 border border-white w-20 text-center','wire:click' => 'showEditDesModel('.e($item->id).')']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                      </td>
                      </tr>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
                      
  
                      <!-- More items... -->
                    </tbody>
                  </table>
                  <div class="px-3 py-3 bg-sky-800 text-2xl rounded-bl-lg rounded-br-lg">
                    <?php echo e($des->links()); ?>

                  </div>
                  <div class="m-2 p-2"></div>
                
  </div>              

  
<div>
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'showingDesModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'showingDesModal']); ?>
                
           
            <?php if($isEditMode): ?>
             <?php $__env->slot('title', null, []); ?> Update Designation <?php $__env->endSlot(); ?>
            <?php else: ?>
             <?php $__env->slot('title', null, []); ?> Create New Designation <?php $__env->endSlot(); ?>
            <?php endif; ?>  
                
                   
                

            
             <?php $__env->slot('content', null, []); ?> 
                <div >
                    <form enctype="multipart/form-data">

                      <div class="sm:col-span-6">
                        <label for="designation" class="block text-sm font-medium text-sky-800"> Designation / තනතුර</label>
                        <div class="mt-1">
                          <input type="text" id="designation" wire:model.lazy="designation" name="designation" class="block text-sky-800  border-sky-700 focus:border-sky-400 focus:ring focus:ring-sky-200 focus:ring-opacity-50 w-full  appearance-none bg-white border  rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                        </div>
                        <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>

                      <div class="sm:col-span-6">
                        <label for="approved_OT_hours" class="block text-sm font-medium text-sky-800"> OT Range 1</label>
                        <div class="mt-1">
                          <input type="text" id="approved_OT_hours1" wire:model.lazy="approved_OT_hours1" name="approved_OT_hours1" class="block text-sky-800  border-sky-700 focus:border-sky-400 focus:ring focus:ring-sky-200 focus:ring-opacity-50 w-full  appearance-none bg-white border  rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                        </div>
                        <?php $__errorArgs = ['approved_OT_hours1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>

                      <div class="sm:col-span-6">
                        <label for="approved_OT_hours" class="block text-sm font-medium text-sky-800"> OT Range 2</label>
                        <div class="mt-1">
                          <input type="text" id="approved_OT_hours2" wire:model.lazy="approved_OT_hours2" name="approved_OT_hours2" class="block text-sky-800  border-sky-700 focus:border-sky-400 focus:ring focus:ring-sky-200 focus:ring-opacity-50 w-full  appearance-none bg-white border  rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                        </div>
                        <?php $__errorArgs = ['approved_OT_hours2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>

                      <div class="sm:col-span-6">
                        <label for="approved_OT_hours" class="block text-sm font-medium text-sky-800"> OT Range 3</label>
                        <div class="mt-1">
                          <input type="text" id="approved_OT_hours3" wire:model.lazy="approved_OT_hours3" name="approved_OT_hours3" class="block text-sky-800  border-sky-700 focus:border-sky-400 focus:ring focus:ring-sky-200 focus:ring-opacity-50 w-full  appearance-none bg-white border  rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                        </div>
                        <?php $__errorArgs = ['approved_OT_hours3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>

                      
                    
                    </form>
                  </div>
                  


             <?php $__env->endSlot(); ?>
             <?php $__env->slot('footer', null, []); ?> 
                
                <?php if($isEditMode): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'editDes','class' => 'bg-sky-800 hover:bg-sky-600 border border-white']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'editDes','class' => 'bg-sky-800 hover:bg-sky-600 border border-white']); ?>Update <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php else: ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'storeDes('.e(Auth::user()->institute).')','class' => 'bg-sky-800 hover:bg-sky-600 border border-white']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'storeDes('.e(Auth::user()->institute).')','class' => 'bg-sky-800 hover:bg-sky-600 border border-white']); ?>Create <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php endif; ?>   
               
             <?php $__env->endSlot(); ?>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>



</div>




<div>
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'showingdeletemodal','class' => ' z-50 bg-opacity-100']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'showingdeletemodal','class' => ' z-50 bg-opacity-100']); ?>
       <?php $__env->slot('title', null, []); ?>  <?php $__env->endSlot(); ?>
    
       <?php $__env->slot('content', null, []); ?> 

        <div class="text-center">
          <label for="designation" class="block text-xl font-medium text-sky-800"> Are you sure you want to delete this record?</label>  
        </div>

        <input type="text" id="deleteID" wire:model.lazy="deleteID" name="deleteID" class="hidden block w-full transition duration-150 ease-in-out appearance-none bg-white border border-gray-400 rounded-md py-2 px-3 text-base leading-normal transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
    
        <div class="text-center p-6 "> 
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'DeleteModal','class' => 'bg-sky-800 hover:bg-red-500']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'DeleteModal','class' => 'bg-sky-800 hover:bg-red-500']); ?>Yes <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>        
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => 'HideDeleteModal','class' => 'bg-sky-800 hover:bg-sky-500']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'HideDeleteModal','class' => 'bg-sky-800 hover:bg-sky-500']); ?>No <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>

       <?php $__env->endSlot(); ?>
      
       <?php $__env->slot('footer', null, []); ?>  <?php $__env->endSlot(); ?>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>



</div>
<?php /**PATH D:\Laravel Project\Laravel9\OT\OT SYS 20230103\resources\views/livewire/manage-designation.blade.php ENDPATH**/ ?>