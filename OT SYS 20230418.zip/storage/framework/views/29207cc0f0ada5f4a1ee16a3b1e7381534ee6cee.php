
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-6 py-5">
                

                <?php if(Auth::user()->user_level == 12): ?>

                    <?php $c=0?> 
                    <?php $__currentLoopData = $level12; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $c++ ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <?php echo e($c); ?> OT Sheets to be Submited</a>
                <?php endif; ?>
                
                
            </div>
        </div>
    </div>
<?php /**PATH D:\Laravel Project\Laravel9\OT\OT SYS 20220907\resources\views/livewire/otdashboard.blade.php ENDPATH**/ ?>