



 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.js"></script>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>



    <div class="max-w mx-auto ">

        <div class="p-6 bg-white">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Dashboard')); ?>

            </h2>
        </div>

        <div class="grid grid-cols-4 gap-4 max-w-7xl mx-auto px-3 py-5">            
            <div class="bg-red-700 overflow-hidden shadow-xl  px-6 py-12 text-md text-white font-medium h-48 text-right ">
                                                    <?php if(Auth::user()->user_level == 8): ?>
                                                        <div class="hidden"> <?php echo e($c=0); ?> </div>  
                                                        <?php $__currentLoopData = $level8_tobesubmite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="hidden">
                                                            <?php echo e($ot_rec_check=DB::table("ot_records")
                                                            ->select('List_id','ot_range')
                                                            ->where('List_id', '=', $item->id )
                                                            ->where('ot_range', '=', $item->ot_range)
                                                            ->count()); ?>   
                                                            </div> 
                                                            <?php if(($ot_rec_check!=0) || ($item->ot_range=='r1') ): ?>
                                                            <div class="hidden"> <?php echo e($c++); ?> </div> 
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> OT Sheets to be <font class="text-2xl">Submitted</font></a>
                                                    <?php endif; ?>

                                                    <?php if(Auth::user()->user_level == 7): ?>
                                                        <div class="hidden"> <?php echo e($c=0); ?> </div>  
                                                        <?php $__currentLoopData = $level7_tobesubmite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="hidden">
                                                            <?php echo e($ot_rec_check=DB::table("ot_records")
                                                            ->select('List_id','ot_range')
                                                            ->where('List_id', '=', $item->id )
                                                            ->where('ot_range', '=', $item->ot_range)
                                                            ->count()); ?>   
                                                            </div> 
                                                            <?php if(($ot_rec_check!=0) || ($item->ot_range=='r1') ): ?>
                                                            <div class="hidden"> <?php echo e($c++); ?> </div> 
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> OT Sheets to be <font class="text-2xl">Submitted</font></a>
                                                    <?php endif; ?>

                                                    <?php if(Auth::user()->user_level == 6): ?>
                                                        <div class="hidden"> <?php echo e($c=0); ?> </div>  
                                                        <?php $__currentLoopData = $level6_tobesubmite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="hidden">
                                                            <?php echo e($ot_rec_check=DB::table("ot_records")
                                                            ->select('List_id','ot_range')
                                                            ->where('List_id', '=', $item->id )
                                                            ->where('ot_range', '=', $item->ot_range)
                                                            ->count()); ?>   
                                                            </div> 
                                                            <?php if(($ot_rec_check!=0) || ($item->ot_range=='r1') ): ?>
                                                                <div class="hidden"> <?php echo e($c++); ?> </div> 
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> OT Sheets to be <font class="text-2xl">Submitted</font></a>
                                                    <?php endif; ?>

                                                    <?php if(Auth::user()->user_level == 5): ?>
                                                        <div class="hidden"> <?php echo e($c=0); ?> </div>  
                                                        <?php $__currentLoopData = $level5_tobesubmite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="hidden">
                                                            <?php echo e($ot_rec_check=DB::table("ot_records")
                                                            ->select('List_id','ot_range')
                                                            ->where('List_id', '=', $item->id )
                                                            ->where('ot_range', '=', $item->ot_range)
                                                            ->count()); ?>   
                                                            </div> 
                                                            <?php if(($ot_rec_check!=0) || ($item->ot_range=='r1') ): ?>
                                                            <div class="hidden"> <?php echo e($c++); ?> </div> 
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> OT Sheets to be <font class="text-2xl">Submitted</font></a>
                                                    <?php endif; ?>

                                                    <?php if(Auth::user()->user_level == 4): ?>
                                                        <div class="hidden"> <?php echo e($c=0); ?> </div>  
                                                        <?php $__currentLoopData = $level4_tobesubmite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="hidden">
                                                            <?php echo e($ot_rec_check=DB::table("ot_records")
                                                            ->select('List_id','ot_range')
                                                            ->where('List_id', '=', $item->id )
                                                            ->where('ot_range', '=', $item->ot_range)
                                                            ->count()); ?>   
                                                            </div> 
                                                            <?php if(($ot_rec_check!=0) || ($item->ot_range=='r1') ): ?>
                                                            <div class="hidden"> <?php echo e($c++); ?> </div> 
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> OT Sheets to be <font class="text-2xl">Submitted</font></a>
                                                    <?php endif; ?>

                                                    <?php if(Auth::user()->user_level == 3): ?>
                                                        <div class="hidden"> <?php echo e($c=0); ?> </div>  
                                                        <?php $__currentLoopData = $level3_tobesubmite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="hidden">
                                                            <?php echo e($ot_rec_check=DB::table("ot_records")
                                                            ->select('List_id','ot_range')
                                                            ->where('List_id', '=', $item->id )
                                                            ->where('ot_range', '=', $item->ot_range)
                                                            ->count()); ?>   
                                                            </div> 
                                                            <?php if(($ot_rec_check!=0) || ($item->ot_range=='r1') ): ?>
                                                            <div class="hidden"> <?php echo e($c++); ?> </div> 
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> OT Sheets to be <font class="text-2xl">Submitted</font></a>
                                                    <?php endif; ?>

                                                    <?php if(Auth::user()->user_level == 2): ?>
                                                        <div class="hidden"> <?php echo e($c=0); ?> </div>  
                                                        <?php $__currentLoopData = $level2_tobesubmite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="hidden">
                                                            <?php echo e($ot_rec_check=DB::table("ot_records")
                                                            ->select('List_id','ot_range')
                                                            ->where('List_id', '=', $item->id )
                                                            ->where('ot_range', '=', $item->ot_range)
                                                            ->count()); ?>   
                                                            </div> 
                                                            <?php if(($ot_rec_check!=0) || ($item->ot_range=='r1') ): ?>
                                                            <div class="hidden"> <?php echo e($c++); ?> </div> 
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> OT Sheets to be <font class="text-2xl">Submitted</font></a>
                                                    <?php endif; ?>
            </div>



            <div class="bg-sky-700 overflow-hidden shadow-xl  px-6 py-12 text-lg text-white font-medium h-48 text-right ">

                <?php if(Auth::user()->user_level == 8): ?>
                    <div class="hidden"> <?php echo e($c=0); ?> </div>  
                    <?php $__currentLoopData = $resubmit8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="hidden"> <?php echo e($c++); ?> </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> <font class="text-2xl">Resubmitted</font> OT Sheets</a>
                <?php endif; ?>

                <?php if(Auth::user()->user_level == 7): ?>
                    <div class="hidden"> <?php echo e($c=0); ?> </div>  
                    <?php $__currentLoopData = $resubmit7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="hidden"> <?php echo e($c++); ?> </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> <font class="text-2xl">Resubmitted</font> OT Sheets</a>
                <?php endif; ?>

                <?php if(Auth::user()->user_level == 6): ?>
                    <div class="hidden"> <?php echo e($c=0); ?> </div>  
                    <?php $__currentLoopData = $resubmit6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="hidden"> <?php echo e($c++); ?> </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> <font class="text-2xl">Resubmitted</font> OT Sheets</a>
                <?php endif; ?>

                <?php if(Auth::user()->user_level == 5): ?>
                    <div class="hidden"> <?php echo e($c=0); ?> </div>  
                    <?php $__currentLoopData = $resubmit5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="hidden"> <?php echo e($c++); ?> </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> <font class="text-2xl">Resubmitted</font> OT Sheets</a>
                <?php endif; ?>

                <?php if(Auth::user()->user_level == 4): ?>
                    <div class="hidden"> <?php echo e($c=0); ?> </div>  
                    <?php $__currentLoopData = $resubmit4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="hidden"> <?php echo e($c++); ?> </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> <font class="text-2xl">Resubmitted</font> OT Sheets</a>
                <?php endif; ?>

                <?php if(Auth::user()->user_level == 3): ?>
                    <div class="hidden"> <?php echo e($c=0); ?> </div>  
                    <?php $__currentLoopData = $resubmit3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="hidden"> <?php echo e($c++); ?> </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> <font class="text-2xl">Resubmitted</font> OT Sheets</a>
                <?php endif; ?>

                <?php if(Auth::user()->user_level == 2): ?>
                    <div class="hidden"> <?php echo e($c=0); ?> </div>  
                    <?php $__currentLoopData = $resubmit2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="hidden"> <?php echo e($c++); ?> </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('ot.list', ['param' =>  Auth::user()->institute ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> <font class="text-2xl">Resubmitted</font> OT Sheets</a>
                <?php endif; ?>
            </div>





            
            <div class="bg-orange-700 overflow-hidden shadow-xl  px-6 py-12 text-white font-medium h-48 text-right ">
                                                    <?php if((Auth::user()->user_level > 6) ): ?>
                                                    <div class="hidden"> <?php echo e($c=0); ?> </div>  
                                                        <?php $__currentLoopData = $incomplete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="hidden">
                                                            <?php echo e($ot_rec_check=DB::table("ot_records")
                                                            ->select('List_id','ot_range')
                                                            ->where('List_id', '=', $item->id )
                                                            ->where('ot_range', '=', $item->ot_range)
                                                            ->count()); ?>   
                                                            </div> 
                                                            <?php if(($ot_rec_check!=0) || ($item->ot_range=='r1') ): ?>
                                                            <div class="hidden"> <?php echo e($c++); ?> </div> 
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('ot.list.status', ['param' =>  Auth::user()->institute ,'param2' =>  'I'])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> <font class="text-2xl">Incomplete</font> OT Sheets</a>
                                                    <?php else: ?>
                                                        <div class="hidden"> <?php echo e($c=0); ?> </div>  
                                                        <?php $__currentLoopData = $incompleteall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="hidden">
                                                            <?php echo e($ot_rec_check=DB::table("ot_records")
                                                            ->select('List_id','ot_range')
                                                            ->where('List_id', '=', $item->id )
                                                            ->where('ot_range', '=', $item->ot_range)
                                                            ->count()); ?>   
                                                            </div> 
                                                            <?php if(($ot_rec_check!=0) || ($item->ot_range=='r1') ): ?>
                                                            <div class="hidden"> <?php echo e($c++); ?> </div> 
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('ot.list.status', ['param' =>  Auth::user()->institute ,'param2' =>  'I'])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> <font class="text-2xl">Incomplete</font> OT Sheets</a>                    
                                                    <?php endif; ?>                      
            </div>






            <div class="bg-green-700 overflow-hidden shadow-xl  px-6 py-12 text-lg text-white font-medium h-48 text-right ">
                                                    <?php if((Auth::user()->user_level > 6) ): ?>
                                                        <div class="hidden"> <?php echo e($c=0); ?> </div>  
                                                        <?php $__currentLoopData = $complete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="hidden"> <?php echo e($c++); ?> </div>  
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('ot.list.status', ['param' =>  Auth::user()->institute,'param2' =>  'C' ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> <font class="text-2xl">Completed</font> OT Sheets</a>
                                                    <?php else: ?>
                                                        <div class="hidden"> <?php echo e($c=0); ?> </div> 
                                                        <?php $__currentLoopData = $completeall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="hidden"> <?php echo e($c++); ?> </div>  
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('ot.list.status', ['param' =>  Auth::user()->institute,'param2' =>  'C' ])); ?>"> <div class="text-6xl font-bold"><?php echo e($c); ?></div> <font class="text-2xl">Completed</font> OT Sheets</a>
                                                    <?php endif; ?>                              
            </div>


            
        </div>



        
        <div class="grid grid-cols-1 gap-4 max-w-6xl mx-auto px-3 py-5 ">

            
            <div class="text-center text-xl">
                <?php echo e(now()->year); ?>  Total OT Hours -  Month Wise Count
              </div>
                      
              <div class="chart-container">
                <div class="pie-chart-container">
                  <canvas id="pie-chart"></canvas>
                </div>
              </div>
             
              <!-- javascript -->
             
               <script>
              $(function(){
                  //get the pie chart canvas
                  var cData = JSON.parse(`<?php echo $chart_data; ?>`);
                  var ctx = $("#pie-chart");
             
                  //pie chart data
                  var data = {
                    labels: cData.label,
                    datasets: [
                      {
                        label: "OT Hours Count",
                        data: cData.data,
                        backgroundColor: [
                          "#0d70a6",
                          "#0d70a6",
                          "#0d70a6",
                          "#0d70a6",
                          "#0d70a6",
                          "#0d70a6",
                          "#0d70a6",
                        ],
                        borderColor: [
                          "#074363",
                          "#074363",
                          "#074363",
                          "#074363",
                          "#074363",
                          "#074363",
                          "#074363",
                        ],
                        borderWidth: [1, 1, 1, 1, 1,1,1]
                      }
                    ]
                  };
             
                  //options
                  msg=""

                  var options = {
                    responsive: true,
                    title: {
                      display: true,
                      position: "top",
                      text:  msg,
                      fontSize: 18,
                      fontColor: "#111"
                    },
                    legend: {
                      display: true,
                      position: "bottom",
                      labels: {
                        fontColor: "#333",
                        fontSize: 16
                      }
                    }
                  };
             
                  //create Pie Chart class object
                  var chart1 = new Chart(ctx, {
                    type: "bar",
                    data: data,
                    options: options
                  });
             
              });
            </script>


              
            <div class="text-center"><div id="chartContainer" class=" text-center"></div>
            
        </div>




        
    </div>



    

                   

                    
                    
                    
                    

                  
    </div>
    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>




<?php /**PATH D:\Laravel Project\Laravel9\OT\OT SYS 20221123-2\resources\views/livewire/otdashboard.blade.php ENDPATH**/ ?>