<!DOCTYPE html>
<html>
<head>
    <title>DOA - OTMS</title>
</head>
<body>
    <h1>{{ $mailData['title'] }}</h1>
    <p>{{ $mailData['body'] }}</p>
    <p>{{ $mailData['email'] }}</p>
  
    <p>http://rop.w3dtec.net/</p>

    <p>Note - This is a system generated email. Please do not reply to this message.</p> 
    <p>Thank you</p>
</body>
</html>